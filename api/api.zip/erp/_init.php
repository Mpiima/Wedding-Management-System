<?php

declare(strict_types=1);

require_once __DIR__ . '/../connect/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

/**
 * Require logged-in school user (not super_admin without ssid).
 */
function erp_school_id(PDO $dbh): string
{
    $ssid = isset($_SESSION['ssid']) ? (string) $_SESSION['ssid'] : '';
    if ($ssid === '' || $ssid === '0') {
        http_response_code(401);
        echo json_encode(['error' => 'School session required', 'data' => null]);
        exit;
    }
    return $ssid;
}

function erp_json_body(): array
{
    global $input;
    return is_array($input) ? $input : [];
}

function erp_send($payload, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

function erp_row_school(PDO $dbh, string $sql, array $params): ?array
{
    $st = $dbh->prepare($sql);
    $st->execute($params);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

function erp_deactivate_other_years(PDO $dbh, string $school, int $exceptId): void
{
    $st = $dbh->prepare('UPDATE academic_years SET is_active = 0 WHERE school_number = ? AND id <> ?');
    $st->execute([$school, $exceptId]);
}

function erp_deactivate_other_periods(PDO $dbh, string $school, int $yearId, int $exceptId): void
{
    $st = $dbh->prepare(
        'UPDATE study_periods SET is_active = 0 WHERE school_number = ? AND academic_year_id = ? AND id <> ?'
    );
    $st->execute([$school, $yearId, $exceptId]);
}

function erp_year_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM academic_years WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}

function erp_period_owned(PDO $dbh, string $school, int $id): ?array
{
    return erp_row_school(
        $dbh,
        'SELECT * FROM study_periods WHERE id = ? AND school_number = ? LIMIT 1',
        [$id, $school]
    );
}

function erp_level_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM levels WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}

function erp_class_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM classes WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}

function erp_stream_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM streams WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}

function erp_student_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM students WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}

function erp_subject_owned(PDO $dbh, string $school, int $id): bool
{
    $st = $dbh->prepare('SELECT id FROM subjects WHERE id = ? AND school_number = ? LIMIT 1');
    $st->execute([$id, $school]);
    return (bool) $st->fetchColumn();
}
